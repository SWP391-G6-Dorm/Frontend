# Homestay / Resort Booking Management System

A web application for managing online homestay and resort room discovery, booking, contract generation, payment tracking, and property management.

## Tech Stack

- **Frontend**: ReactJS, TypeScript, Vite, TailwindCSS, Zustand / Redux Toolkit, React Query, Axios
- **Backend**: Java Spring Boot, Spring Security, Spring Data JPA, Hibernate, JWT, JavaMail (SMTP), iText / Apache PDFBox, PostgreSQL
- **DevOps**: Docker, GitHub Actions, Nginx

## Commands

### Frontend (in `frontend/`)

- Install dependencies: `npm install`
- Run dev server: `npm run dev`
- Build production: `npm run build`
- Lint: `npm run lint`
- Test: `npm run test`

### Backend (in `backend/`)

- Run dev server: `./mvnw spring-boot:run`
- Run tests: `./mvnw test`
- Build package: `./mvnw clean package`

## Project Structure

```
frontend/src/
  api/           components/    configs/    constants/
  features/      hooks/         layouts/    pages/
  routes/        services/      store/      styles/
  types/         utils/         main.tsx

backend/src/main/java/com/homestay/
  configs/       controllers/   dtos/       entities/
  enums/         exceptions/    filters/    mappers/
  repositories/  security/      services/   specifications/
  utils/         validations/
```

## Roles

- **Guest** — unauthenticated, can browse rooms and register
- **Customer** — authenticated, can book rooms, pay, submit tickets and reviews
- **Manager** — full system access: properties, rooms, bookings, payments, contracts, reports

## Architecture & Coding Rules

### Frontend

- Feature-based folder structure with component-based architecture.
- Use functional components only, typed with TypeScript interfaces.
- Global state: Zustand or Redux Toolkit. Server state: React Query.
- Styling: TailwindCSS. Avoid inline CSS. Use responsive design (desktop + mobile).
- Centralized Axios instance with interceptors for JWT token, refresh token, and error handling.
- Use lazy loading and code splitting for performance.

### Backend

- Layered architecture: Controller → Service → Repository → Entity.
- Follow SOLID principles and the DTO pattern. Keep controllers thin.
- Always use constructor injection.
- Validation: Bean Validation on all DTOs. Global exception handler via `@RestControllerAdvice`.
- Entities must have: `id (UUID)`, `createdAt`, `updatedAt`.
- Use `@Transactional` for: booking creation, deposit/remaining payment processing, contract generation, booking cancellation.
- Pagination required on all list endpoints.

## Business Rules (Critical)

- Booking is created with status `PENDING_DEPOSIT`.
- After Manager verifies deposit → `Booking.status = CONFIRMED` + Contract PDF auto-generated + emailed.
- Deposit = **40%** of total, Remaining = **60%** (configurable via SystemSetting).
- Deposit is **non-refundable** after payment.
- Customer can only review after `Booking.status = CHECKED_OUT`. One review per booking.
- Room statuses: `AVAILABLE` / `PENDING_DEPOSIT` / `RESERVED` / `OCCUPIED` / `MAINTENANCE`.

## API Standards

```
Success: { "success": true,  "message": "Success",           "data": {} }
Error:   { "success": false, "message": "Validation failed", "errors": [] }

Auth header:   Authorization: Bearer <jwt-token>
Pagination:    ?page=0&size=10&sort=createdAt,desc
```

## Security Rules

- **NEVER**: Hardcode secrets, expose JWT secrets, log passwords or tokens, use insecure SQL.
- **ALWAYS**: Validate user input, use parameterized queries, sanitize payloads, protect Manager-only APIs with RBAC, verify payment receipts before confirming.
- Encrypt passwords with BCrypt. Use HTTPS in production.

## Git Rules

- **Branch naming**: `feature/room-booking`, `bugfix/availability-calendar`, `hotfix/security-patch`
- **Commit convention**: `feat:`, `fix:`, `refactor:`, `docs:`, `chore:`

## Testing & Performance

- **Coverage target**: >= 80%
- **Required tests**: Unit tests, integration tests, API validation tests.
- **Performance**: Pagination on all lists, avoid N+1 queries, add indexes on `email`, `property_id`, `room_id`, `booking_id`, `customer_id`.
